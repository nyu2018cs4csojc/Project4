#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

SDL_Window* displayWindow;
bool gameIsRunning = true;
bool jump = false;
bool lose = false;
bool win = false;
bool done = false;

ShaderProgram program;
glm::mat4 viewMatrix, projectionMatrix;
GLuint TextureIDPlatform;
GLuint TextureIDEnemy;
GLuint TextureIDPlayer;
GLuint TextureIDFont;

class Entity
{
public:
	glm::mat4 modelMatrix;
	GLuint TextureID;
	float vertices[12];
	float texcoords[12];
	glm::vec3 position;
	glm::vec3 velocity;
	glm::vec3 acceleration;
	Entity()
	{
		modelMatrix = glm::mat4(1.0f);
		velocity = glm::vec3(0);
		acceleration = glm::vec3(0);
	}
	Entity(glm::vec3 p, float w, float h, GLuint t): texcoords{ 0, h, w, h, w, 0, 0, h, w, 0, 0, 0 }, vertices{ -w/2, -h/2, w/2, -h/2, w/2, h/2, -w/2, -h/2, w/2, h/2, -w/2, h/2}
	{
		modelMatrix = glm::mat4(1.0f);
		velocity = glm::vec3(0);
		acceleration = glm::vec3(0);
		position = p;
		TextureID = t;
		modelMatrix = glm::translate(modelMatrix, position);
	}
	void Update(float deltaTime)
	{
		velocity += acceleration * deltaTime;
		position += velocity * deltaTime;
		modelMatrix = glm::mat4(1.0f);
		modelMatrix = glm::translate(modelMatrix, position);
	}
	void Render()
	{
		program.SetModelMatrix(modelMatrix);
		glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
		glEnableVertexAttribArray(program.positionAttribute);
		glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texcoords);
		glEnableVertexAttribArray(program.texCoordAttribute);
		glBindTexture(GL_TEXTURE_2D, TextureID);
		glDrawArrays(GL_TRIANGLES, 0, 6);
		glDisableVertexAttribArray(program.positionAttribute);
		glDisableVertexAttribArray(program.texCoordAttribute);
	}
};

struct Gamestate
{
	Entity* platforms[4];
	Entity* enemies[3];
	Entity* player;
	Entity* text[7];
};

Gamestate game;

GLuint LoadTexture(const char* filePath) {
	int w, h, n;
	unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);
	if (image == NULL) {
		std::cout << "Unable to load image. Make sure the path is correct\n";
		assert(false);
	}
	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	stbi_image_free(image);
	return textureID;
}

void Initialize() {
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Rise of the AI!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);
#ifdef _WINDOWS
	glewInit();
#endif
	glViewport(0, 0, 640, 480);
	program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
	viewMatrix = glm::mat4(1.0f);
	projectionMatrix = glm::ortho(-5.0f, 5.0f, -4.0f, 4.0f, -1.0f, 1.0f);
	program.SetProjectionMatrix(projectionMatrix);
	program.SetViewMatrix(viewMatrix);
	glUseProgram(program.programID);
	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	TextureIDPlatform = LoadTexture("moon.jpg");
	TextureIDEnemy = LoadTexture("enemy.png");
	TextureIDPlayer = LoadTexture("player.jpg");
	TextureIDFont = LoadTexture("font1.png");

	game.platforms[0] = new Entity(glm::vec3(0.0, -3.5, 0), 10, 1, TextureIDPlatform);
	game.platforms[1] = new Entity(glm::vec3(-3.0, -1.5, 0), 4, 1, TextureIDPlatform);
	game.platforms[2] = new Entity(glm::vec3(3.0, 0.5, 0), 4, 1, TextureIDPlatform);
	game.platforms[3] = new Entity(glm::vec3(-2.0, 2.5, 0), 2, 1, TextureIDPlatform);
	game.enemies[0] = new Entity(glm::vec3(0.0, -2.5, 0), 1, 1, TextureIDEnemy);
	game.enemies[1] = new Entity(glm::vec3(-1.5, -0.5, 0), 1, 1, TextureIDEnemy);
	game.enemies[2] = new Entity(glm::vec3(1.5, 1.5, 0), 1, 1, TextureIDEnemy);
	for (int i = 0; i < 3; i++) { game.enemies[i]->velocity.x = 1; }
	game.player = new Entity(glm::vec3(-2, 3.5, 0), 1, 1, TextureIDPlayer);
}

void ProcessInput() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		switch (event.type)
		{
		case SDL_QUIT:
		case SDL_WINDOWEVENT_CLOSE:
			gameIsRunning = false;
			break;
		case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_SPACE)
			{
				jump = true;
			}
			break;
		}
	}
	const Uint8* keys = SDL_GetKeyboardState(NULL);
	if (keys[SDL_SCANCODE_LEFT])
	{
		game.player->velocity.x += -0.001;
	}
	else if (keys[SDL_SCANCODE_RIGHT])
	{
		game.player->velocity.x += 0.001;
	}
}

#define FIXED_TIMESTEP 0.016f
float lastTicks = 0;
float accumulator = 0.0f;
float endtime = 0;

void GameUpdate()
{
	game.player->acceleration.y = -0.981;
	if (game.player->position.x >= 4.5)
	{
		game.player->velocity.x = -1;
	}
	else if (game.player->position.x <= -4.5)
	{
		game.player->velocity.x = 1;
	}
	for (int i = 0; i < 4; i++)
	{
		if (game.player->position.x > game.platforms[i]->position.x + game.platforms[i]->vertices[0] - 0.5 && game.player->position.x < game.platforms[i]->position.x + game.platforms[i]->vertices[2] + 0.5)
		{
			if (game.player->position.y - game.platforms[i]->position.y <= 1 && game.player->position.y > game.platforms[i]->position.y + game.platforms[i]->vertices[5])
			{
				game.player->acceleration.y = 0;
				game.player->velocity.y = 0;
			}
			else if (game.platforms[i]->position.y - game.player->position.y <= 1 && game.player->position.y < game.platforms[i]->position.y + game.platforms[i]->vertices[1])
			{
				game.player->acceleration.y = -0.981;
				if (game.player->velocity.y > 0) { game.player->velocity.y = -1; }
			}
		}
		if (abs(game.player->position.y - game.platforms[i]->position.y) < 1)
		{
			if (game.platforms[i]->position.x + game.platforms[i]->vertices[0] - game.player->position.x <= 0.5 && game.player->position.x < game.platforms[i]->position.x + game.platforms[i]->vertices[0])
			{
				game.player->velocity.x = -1;
			}
			else if (game.player->position.x - (game.platforms[i]->position.x + game.platforms[i]->vertices[2]) <= 0.5 && game.player->position.x > game.platforms[i]->position.x + game.platforms[i]->vertices[2])
			{
				game.player->velocity.x = 1;
			}
		}
	}
	if (jump) { game.player->acceleration.y = 100; jump = false; }
	for (int i = 0; i < 3; i++)
	{
		if (game.enemies[i] == nullptr) { continue; }
		if (abs(game.player->position.x - game.enemies[i]->position.x) < 1 && abs(game.player->position.y - game.enemies[i]->position.y) < 1)
		{
			if (game.player->position.y <= game.enemies[i]->position.y + game.enemies[i]->vertices[5])
			{
				lose = true;
				return;
			}
			else
			{
				delete game.enemies[i];
				game.enemies[i] = nullptr;
				continue;
			}
		}
		if (game.enemies[i]->position.x <= -4 || game.enemies[i]->position.x >= 4)
		{
			game.enemies[i]->velocity.x *= -1;
		}
		if (abs(game.player->position.y - game.enemies[i]->position.y) < 1)
		{
			if (game.player->position.x > game.enemies[i]->position.x)
			{
				game.enemies[i]->acceleration.x = 5;
			}
			else
			{
				game.enemies[i]->acceleration.x = -5;
			}
		}
		else if (abs(game.enemies[i]->position.x - game.player->position.x) < 1 && game.player->position.y > game.enemies[i]->position.y)
		{
			game.enemies[i]->acceleration.x = game.enemies[i]->velocity.x * 5;
		}
		else
		{
			game.enemies[i]->acceleration.x = 0;
			game.enemies[i]->velocity.x = game.enemies[i]->velocity.x / abs(game.enemies[i]->velocity.x);
		}
		game.enemies[i]->Update(FIXED_TIMESTEP);

	}
	if (game.enemies[0] == nullptr && game.enemies[1] == nullptr && game.enemies[2] == nullptr)
	{
		win = true;
		return;
	}
	game.player->Update(FIXED_TIMESTEP);
}

void Update() {
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	float deltaTime = ticks - lastTicks;
	lastTicks = ticks;
	deltaTime += accumulator;
	if (deltaTime < FIXED_TIMESTEP)
	{
		accumulator = deltaTime;
		return;
	}
	while (deltaTime >= FIXED_TIMESTEP)
	{
		if (!lose && !win)
		{
		    GameUpdate();
		}
		deltaTime -= FIXED_TIMESTEP;
	}
	accumulator = deltaTime;
}

void Message()
{
	int words[7];
	words[0] = 'Y';
	words[1] = 'O';
	words[2] = 'U';
	if (win) { words[3] = 'W'; words[4] = 'I'; words[5] = 'N'; words[6] = '!'; }
	if (lose) { words[3] = 'L'; words[4] = 'O'; words[5] = 'S'; words[6] = 'E'; }
	float wh = 1.0 / 16;
	for (int i = 0; i < 7; i++)
	{
		float x = -3.5 + i;
		if (i >= 3) { x++; }
		game.text[i] = new Entity(glm::vec3(x, 1.5, 0), 1, 1, TextureIDFont);
		float u = (float)(words[i] % 16) / 16;
		float v = (float)(words[i] / 16) / 16;
		game.text[i]->texcoords[0] = u;
		game.text[i]->texcoords[1] = v + wh;
		game.text[i]->texcoords[2] = u + wh;
		game.text[i]->texcoords[3] = v + wh;
		game.text[i]->texcoords[4] = u + wh;
		game.text[i]->texcoords[5] = v;
		game.text[i]->texcoords[6] = u;
		game.text[i]->texcoords[7] = v + wh;
		game.text[i]->texcoords[8] = u + wh;
		game.text[i]->texcoords[9] = v;
		game.text[i]->texcoords[10] = u;
		game.text[i]->texcoords[11] = v;
	}
}

void Render() {
	glClear(GL_COLOR_BUFFER_BIT);

	game.platforms[0]->Render();
	game.platforms[1]->Render();
	game.platforms[2]->Render();
	game.platforms[3]->Render();
	game.player->Render();
	for (int i = 0; i < 3; i++)
	{
		if (game.enemies[i] != nullptr)
		{
			game.enemies[i]->Render();
		}
	}
	if (win || lose)
	{
		if (!done)
		{
			Message();
			done = true;
		}
		for (int i = 0; i < 7; i++)
		{
			game.text[i]->Render();
		}
	}

	SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
	SDL_Quit();
}

int main(int argc, char* argv[]) {
	Initialize();

	while (gameIsRunning) {
		ProcessInput();
		Update();
		Render();
	}

	Shutdown();
	return 0;
}

